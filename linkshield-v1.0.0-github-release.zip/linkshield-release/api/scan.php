<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/../config.php';

function out(array $x,int $code=200): never {
    http_response_code($code); echo json_encode($x, JSON_UNESCAPED_SLASHES); exit;
}
function curlJson(string $url,array $headers=[],string $method='GET',?string $body=null,int $timeout=8): array {
    $ch=curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>4,
        CURLOPT_HTTPHEADER=>$headers,CURLOPT_CUSTOMREQUEST=>$method,
        CURLOPT_USERAGENT=>'LinkShield/1.0'
    ]);
    if($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,$body);
    $raw=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    if($raw===false) return ['_error'=>$err,'_code'=>$code];
    $j=json_decode($raw,true); return is_array($j)?$j:['_raw'=>$raw,'_code'=>$code];
}
function normalizeUrl(string $url): string {
    $url=trim($url);
    if(!preg_match('~^[a-z][a-z0-9+\-.]*://~i',$url)) $url='https://'.$url;
    if(strlen($url)>2048) throw new RuntimeException('URL is too long.');
    if(!filter_var($url,FILTER_VALIDATE_URL)) throw new RuntimeException('Invalid URL.');
    $p=parse_url($url);
    if(!$p || empty($p['host'])) throw new RuntimeException('Invalid hostname.');
    if(isset($p['user'])||isset($p['pass'])) throw new RuntimeException('Userinfo in URLs is not accepted.');
    return $url;
}
function isPrivateIp(string $ip): bool {
    if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
        $n=ip2long($ip); return (($n>=ip2long('10.0.0.0')&&$n<=ip2long('10.255.255.255'))||
        ($n>=ip2long('172.16.0.0')&&$n<=ip2long('172.31.255.255'))||
        ($n>=ip2long('192.168.0.0')&&$n<=ip2long('192.168.255.255'))||
        $ip==='127.0.0.1'||$ip==='0.0.0.0');
    }
    return filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)===false;
}
function localSignals(string $url): array {
    $p=parse_url($url); $host=strtolower($p['host']??''); $score=0; $checks=[]; $reasons=[];
    $https=(($p['scheme']??'')==='https');
    $checks[]=['name'=>'HTTPS','status'=>$https?'PASS':'WARNING','level'=>$https?'ok':'warn'];
    if(!$https){$score+=10;$reasons[]='Connection is not HTTPS.';}
    if(filter_var($host,FILTER_VALIDATE_IP)){ $score+=15;$checks[]=['name'=>'IP address host','status'=>'WARNING','level'=>'warn'];$reasons[]='URL uses an IP address instead of a domain.';}
    else $checks[]=['name'=>'IP address host','status'=>'PASS','level'=>'ok'];
    if(strpos($host,'xn--')!==false){$score+=20;$checks[]=['name'=>'Punycode domain','status'=>'WARNING','level'=>'warn'];$reasons[]='Punycode can be legitimate but is also used in homograph phishing.';}
    else $checks[]=['name'=>'Punycode domain','status'=>'PASS','level'=>'ok'];
    $badTlds=['.zip','.mov','.click','.top','.gq','.tk','.ml','.ga','.cf'];
    foreach($badTlds as $t) if(str_ends_with($host,$t)){ $score+=10;$checks[]=['name'=>'High-abuse TLD signal','status'=>'WARNING','level'=>'warn'];$reasons[]='Domain uses a TLD frequently seen in abuse reports.'; break; }
    $keywords=['login','verify','secure','account','password','wallet','update','invoice','payment'];
    $hits=0; foreach($keywords as $k) if(str_contains($host,$k)) $hits++;
    if($hits>=2){$score+=12;$checks[]=['name'=>'Phishing-style hostname words','status'=>'WARNING','level'=>'warn'];$reasons[]='Hostname contains multiple sensitive-account keywords.';}
    else $checks[]=['name'=>'Phishing-style hostname words','status'=>'PASS','level'=>'ok'];
    $checks[]=['name'=>'URL length','status'=>strlen($url)>300?'WARNING':'PASS','level'=>strlen($url)>300?'warn':'ok'];
    if(strlen($url)>300){$score+=8;$reasons[]='Unusually long URL.';}
    return [$score,$checks,$reasons,$p,$host];
}
try{
    $input=json_decode(file_get_contents('php://input'),true) ?: $_POST;
    $url=normalizeUrl((string)($input['url']??''));
    [$score,$checks,$reasons,$p,$host]=localSignals($url);

    $providers=[];

    // Google Safe Browsing v4
    $gkey=$config['apis']['google_safe_browsing_key']??'';
    if($gkey){
        $endpoint='https://safebrowsing.googleapis.com/v4/threatMatches:find?key='.rawurlencode($gkey);
        $body=json_encode(['client'=>['clientId'=>'linkshield','clientVersion'=>'1.0'],
          'threatInfo'=>['threatTypes'=>['MALWARE','SOCIAL_ENGINEERING','UNWANTED_SOFTWARE','POTENTIALLY_HARMFUL_APPLICATION'],
          'platformTypes'=>['ANY_PLATFORM'],'threatEntryTypes'=>['URL'],'threatEntries'=>[['url'=>$url]]]]);
        $g=curlJson($endpoint,['Content-Type: application/json'],'POST',$body,$config['app']['request_timeout']??8);
        $providers['google_safe_browsing']=$g;
        if(!empty($g['matches'])){$score+=70;$checks[]=['name'=>'Google Safe Browsing','status'=>'THREAT MATCH','level'=>'bad'];$reasons[]='Google Safe Browsing reported a threat match.';}
        else $checks[]=['name'=>'Google Safe Browsing','status'=>'NO MATCH','level'=>'ok'];
    }else $checks[]=['name'=>'Google Safe Browsing','status'=>'NOT CONFIGURED','level'=>'warn'];

    // VirusTotal URL lookup requires the URL ID = base64url(url) without '='.
    $vkey=$config['apis']['virustotal_key']??'';
    if($vkey){
        $id=rtrim(strtr(base64_encode($url),'+/','-_'),'=');
        $v=curlJson('https://www.virustotal.com/api/v3/urls/'.$id,['x-apikey: '.$vkey], 'GET',null,$config['app']['request_timeout']??8);
        $providers['virustotal']=$v;
        $mal=(int)($v['data']['attributes']['last_analysis_stats']['malicious']??0);
        $sus=(int)($v['data']['attributes']['last_analysis_stats']['suspicious']??0);
        if($mal>0){$score+=min(80,$mal*12);$checks[]=['name'=>'VirusTotal','status'=>$mal.' malicious detections','level'=>'bad'];$reasons[]='VirusTotal has malicious detections.';}
        elseif($sus>0){$score+=min(35,$sus*5);$checks[]=['name'=>'VirusTotal','status'=>$sus.' suspicious detections','level'=>'warn'];$reasons[]='VirusTotal has suspicious detections.';}
        else $checks[]=['name'=>'VirusTotal','status'=>'NO MALICIOUS DETECTIONS','level'=>'ok'];
    }else $checks[]=['name'=>'VirusTotal','status'=>'NOT CONFIGURED','level'=>'warn'];

    // URLScan: submit a scan only if configured. This is intentionally not automatic
    // by default because submissions can make a URL visible to a third-party service.
    $ukey=$config['apis']['urlscan_key']??'';
    if($ukey) $checks[]=['name'=>'URLScan','status'=>'KEY CONFIGURED (submission disabled by default)','level'=>'ok'];
    else $checks[]=['name'=>'URLScan','status'=>'NOT CONFIGURED','level'=>'warn'];

    $score=min(100,$score);
    $verdict=$score>=70?'dangerous':($score>=30?'suspicious':($score<=10?'safe':'unknown'));
    if(!empty($g['matches']) || ($mal??0)>0) $verdict='dangerous';
    $summary=$verdict==='dangerous'?'Strong threat indicators detected. Do not open or submit credentials.':
      ($verdict==='suspicious'?'One or more risk indicators were found. Treat this URL with caution.':
      ($verdict==='safe'?'No configured threat source reported a threat and local checks found few risk indicators.':'Not enough evidence to classify this URL confidently.'));

    $details=[
      'Host'=>$host,
      'Scheme'=>$p['scheme']??'',
      'Port'=>$p['port']??(($p['scheme']??'')==='https'?'443':'80'),
      'Path'=>$p['path']??'/',
      'Query present'=>isset($p['query'])?'Yes':'No',
      'Configured providers'=>trim(($gkey?'Google Safe Browsing, ':'').($vkey?'VirusTotal, ':'').($ukey?'URLScan':'')
        ,', ') ?: 'Local checks only'
    ];
    out(['ok'=>true,'verdict'=>$verdict,'score'=>$score,'summary'=>$summary,'normalized_url'=>$url,
      'checks'=>$checks,'details'=>$details,'reasons'=>$reasons,'providers'=>array_keys($providers)]);
}catch(Throwable $e){out(['ok'=>false,'error'=>$e->getMessage()],400);}
