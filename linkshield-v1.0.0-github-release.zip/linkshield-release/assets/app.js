const form=document.getElementById('scanForm');
const loading=document.getElementById('loading');
const result=document.getElementById('result');

form.addEventListener('submit',async e=>{
  e.preventDefault();
  const url=document.getElementById('url').value.trim();
  loading.classList.remove('hidden'); result.classList.add('hidden');
  try{
    const r=await fetch('api/scan.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url})});
    const data=await r.json();
    if(!r.ok||!data.ok) throw new Error(data.error||'Scan failed');
    render(data);
  }catch(err){alert(err.message)}
  finally{loading.classList.add('hidden')}
});

function render(d){
  result.classList.remove('hidden');
  document.getElementById('verdict').textContent=d.verdict.toUpperCase();
  document.getElementById('resultUrl').textContent=d.normalized_url;
  document.getElementById('score').textContent=d.score;
  document.getElementById('summary').textContent=d.summary;
  const checks=document.getElementById('checks'); checks.innerHTML='';
  d.checks.forEach(x=>{
    const el=document.createElement('div'); el.className='check';
    el.innerHTML=`<span>${esc(x.name)}</span><strong class="${x.level}">${esc(x.status)}</strong>`;
    checks.appendChild(el);
  });
  const details=document.getElementById('details'); details.innerHTML='';
  Object.entries(d.details||{}).forEach(([k,v])=>{
    const el=document.createElement('div'); el.className='detail';
    el.innerHTML=`<span>${esc(k)}</span><span>${esc(String(v))}</span>`;
    details.appendChild(el);
  });
}
function esc(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
